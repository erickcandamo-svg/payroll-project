#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <vector>
#include <string>
using namespace std;

struct Employee {
    string ssn;
    string first;
    string middle;
    string last;
    double annualSalary;
    int insured;
    char retirement;
};

double federalTaxRate(double salary) {
    if (salary <= 4999.99) return 0.0;
    if (salary <= 9999.99) return 0.06;
    if (salary <= 19999.99) return 0.15;
    if (salary <= 39999.99) return 0.20;
    if (salary <= 59999.99) return 0.25;
    return 0.30;
}

double calculateMonthlyPay(const Employee& emp) {
    double grossMonthly = emp.annualSalary / 12.0;
    double federal = (emp.annualSalary * federalTaxRate(emp.annualSalary)) / 12.0;
    double state = (emp.annualSalary * 0.06) / 12.0;
    double insurance = emp.insured * 100.0;
    double retirement = (emp.retirement == 'Y') ? grossMonthly * 0.06 : 0.0;
    double net = grossMonthly - (federal + state + insurance + retirement);
    return net;
}

Employee parseEmployee(const string& line) {
    Employee emp;
    stringstream ss(line);
    ss >> emp.ssn >> emp.first >> emp.middle >> emp.last >> emp.annualSalary >> emp.insured >> emp.retirement;
    return emp;
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        cout << "Usage: " << argv[0] << " employees.txt" << endl;
        return 1;
    }

    ifstream infile(argv[1]);
    if (!infile) {
        cerr << "Error: could not open file " << argv[1] << endl;
        return 1;
    }

    vector<Employee> employees;
    string line;
    while (getline(infile, line)) {
        if (!line.empty()) {
            employees.push_back(parseEmployee(line));
        }
    }

    cout << left << setw(12) << "SSN"
         << setw(25) << "Name"
         << right << setw(12) << "Monthly Pay" << endl;
    cout << string(50, '-') << endl;

    for (const auto& emp : employees) {
        double monthlyPay = calculateMonthlyPay(emp);
        string fullname = emp.last + ", " + emp.first + " " + emp.middle + ".";
        cout << left << setw(12) << emp.ssn
             << setw(25) << fullname
             << right << "$" << setw(10) << fixed << setprecision(2) << monthlyPay
             << endl;
    }

    return 0;
}
