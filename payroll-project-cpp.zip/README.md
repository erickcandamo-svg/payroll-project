# Payroll Processing System (C++)

This is a payroll program written in **C++**.  
It reads employee records, calculates monthly payroll after deductions, and displays the results.

## Features
- Federal tax calculation (per tax table)
- 6% state tax
- $100 per insured individual
- 6% retirement deduction (if opted in)

## Files
- `payroll.cpp` – main program
- `employees.txt` – sample employee records

## Compile & Run
```bash
g++ payroll.cpp -o payroll
./payroll employees.txt
```

## Sample Output
```
SSN          Name                      Monthly Pay
--------------------------------------------------
30601234     Furniture, Patty O.       $   3,050.00
340809999    Nasium, Jim N.            $   1,320.00
350905555    Bird, Earl E.             $   2,340.00
360114321    Stein, Frank N.           $   3,400.00
```
